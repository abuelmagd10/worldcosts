# كيفية إضافة لقطات الشاشة إلى تطبيق WorldCosts PWA

هذا الدليل يشرح بالتفصيل كيفية إضافة لقطات الشاشة التي تم مشاركتها إلى تطبيق WorldCosts PWA.

## الصور المطلوبة

يجب إضافة خمس لقطات شاشة:

1. **شاشة إدخال معلومات الشركة**: تظهر نموذج إدخال معلومات الشركة
2. **صفحة المهمة والميزات**: تظهر مهمة التطبيق وميزاته الرئيسية
3. **صفحة إدارة الملفات**: تظهر واجهة إدارة الملفات المرفوعة
4. **شاشة العناصر المضافة والحسابات**: تظهر جدول العناصر المضافة والمبلغ الإجمالي
5. **الشاشة الرئيسية مع العناصر المضافة**: تظهر الصفحة الرئيسية للتطبيق

## خطوات الإضافة

### 1. تحضير الصور

1. احفظ الصور من المحادثة على جهازك
2. قم بتسمية الصور كالتالي:
   - screenshot1.png
   - screenshot2.png
   - screenshot3.png
   - screenshot4.png
   - screenshot5.png
3. تأكد من أن الصور بتنسيق PNG وبأبعاد 1280×720 بكسل

### 2. إنشاء المجلدات المطلوبة

تأكد من وجود المجلدات التالية:

```
public/screenshots/
web/screenshots/
```

إذا لم تكن موجودة، قم بإنشائها:

```bash
mkdir -p public/screenshots
mkdir -p web/screenshots
```

### 3. نسخ الصور إلى المجلدات

قم بنسخ الصور إلى كلا المجلدين:

```bash
# نسخ الصور إلى مجلد public/screenshots
cp screenshot*.png public/screenshots/

# نسخ الصور إلى مجلد web/screenshots
cp screenshot*.png web/screenshots/
```

### 4. التحقق من ملفات manifest

تأكد من أن ملفي `app/manifest.ts` و `web/manifest.json` يشيران إلى الصور الصحيحة:

في `app/manifest.ts`:
```typescript
screenshots: [
  {
    src: "/screenshots/screenshot1.png",
    sizes: "1280x720",
    type: "image/png",
    platform: "wide",
    label: "شاشة إدخال معلومات الشركة",
  },
  // ... باقي الصور
],
```

في `web/manifest.json`:
```json
"screenshots": [
  {
    "src": "screenshots/screenshot1.png",
    "sizes": "1280x720",
    "type": "image/png",
    "platform": "wide",
    "label": "شاشة إدخال معلومات الشركة"
  },
  // ... باقي الصور
],
```

### 5. إضافة الصور إلى Git

```bash
git add public/screenshots/*.png web/screenshots/*.png
git commit -m "إضافة لقطات الشاشة للتطبيق"
git push origin update-pwa-manifest-v2
```

### 6. دمج طلب الدمج

بعد دفع التغييرات، قم بدمج طلب الدمج رقم 13 من خلال واجهة GitHub.

## نصائح إضافية

- تأكد من أن الصور واضحة وذات جودة عالية
- تأكد من أن الصور تعكس أحدث إصدار من التطبيق
- تأكد من أن الصور باللغة العربية لتتوافق مع إعدادات التطبيق
- تجنب إظهار أي معلومات شخصية أو حساسة في الصور
