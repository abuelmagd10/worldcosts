# تعليمات تحميل الصور إلى المجلدات المطلوبة

بعد تحويل الصور من المحادثة إلى ملفات PNG، يجب تحميلها إلى المجلدات المطلوبة في المشروع.

## المجلدات المطلوبة

يجب تحميل الصور إلى مجلدين:

1. `public/screenshots/`
2. `web/screenshots/`

## خطوات التحميل

### الطريقة 1: استخدام واجهة المستخدم الرسومية

1. افتح مستكشف الملفات (File Explorer) في Windows
2. انتقل إلى مجلد المشروع `D:\8\worldcosts`
3. انتقل إلى المجلد `public/screenshots`
4. انسخ الصور الخمس إلى هذا المجلد
5. انتقل إلى المجلد `web/screenshots`
6. انسخ الصور الخمس إلى هذا المجلد أيضًا

### الطريقة 2: استخدام سطر الأوامر

يمكنك استخدام الأوامر التالية في PowerShell:

```powershell
# نسخ الصور إلى مجلد public/screenshots
Copy-Item -Path "مسار_الصور\screenshot1.png" -Destination "D:\8\worldcosts\public\screenshots\"
Copy-Item -Path "مسار_الصور\screenshot2.png" -Destination "D:\8\worldcosts\public\screenshots\"
Copy-Item -Path "مسار_الصور\screenshot3.png" -Destination "D:\8\worldcosts\public\screenshots\"
Copy-Item -Path "مسار_الصور\screenshot4.png" -Destination "D:\8\worldcosts\public\screenshots\"
Copy-Item -Path "مسار_الصور\screenshot5.png" -Destination "D:\8\worldcosts\public\screenshots\"

# نسخ الصور إلى مجلد web/screenshots
Copy-Item -Path "مسار_الصور\screenshot1.png" -Destination "D:\8\worldcosts\web\screenshots\"
Copy-Item -Path "مسار_الصور\screenshot2.png" -Destination "D:\8\worldcosts\web\screenshots\"
Copy-Item -Path "مسار_الصور\screenshot3.png" -Destination "D:\8\worldcosts\web\screenshots\"
Copy-Item -Path "مسار_الصور\screenshot4.png" -Destination "D:\8\worldcosts\web\screenshots\"
Copy-Item -Path "مسار_الصور\screenshot5.png" -Destination "D:\8\worldcosts\web\screenshots\"
```

استبدل "مسار_الصور" بالمسار الفعلي للمجلد الذي حفظت فيه الصور.

## بعد التحميل

بعد تحميل الصور، تأكد من:

1. أن الصور موجودة في كلا المجلدين
2. أن أسماء الصور صحيحة (screenshot1.png, screenshot2.png, إلخ)
3. أن الصور بتنسيق PNG وبأبعاد مناسبة

ثم قم بإضافة الصور إلى Git ودفعها إلى GitHub باستخدام الأوامر التالية:

```bash
git add public/screenshots/*.png web/screenshots/*.png
git commit -m "إضافة لقطات الشاشة للتطبيق"
git push origin update-pwa-manifest-v2
```
